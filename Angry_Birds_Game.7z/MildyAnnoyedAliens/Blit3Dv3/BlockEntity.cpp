#include "BlockEntity.h"

extern b2World *world;
extern std::vector<Sprite *> blockSprites;

BlockEntity * MakeBlock(BlockType btype, MaterialType mtype, b2Vec2 pixelCoords,
	float angleInDegrees, int maximumHP)
{
	BlockEntity * blockEntity = new BlockEntity();
	blockEntity->blockType = btype;
	blockEntity->materialType = mtype;

	b2BodyDef bodyDef;
	
	bodyDef.type = b2_dynamicBody; //make it a dynamic body i.e. one moved by physics
	bodyDef.position = Pixels2Physics(pixelCoords); //set its position in the world
	bodyDef.angle = deg2rad(angleInDegrees);

	bodyDef.angularDamping = 1.8f;

	bodyDef.userData.pointer = reinterpret_cast<uintptr_t> (blockEntity);

	blockEntity->body = world->CreateBody(&bodyDef); //create the body and add it to the world

	b2FixtureDef fixtureDef;

	// Define a shape for our body.
	b2PolygonShape polygon;
	b2CircleShape circle;

	switch (btype)
	{
	case BlockType::LARGE_TRIANGLE:
	{
		// This defines a triangle in CCW order.
		b2Vec2 vertices[3];
		
		float cx = 580 + 140 / 2;
		float cy = 1840 + 70 / 2;

		vertices[0].Set((650.f - cx) / PTM_RATIO, (cy - 1841.0f) / PTM_RATIO);
		vertices[1].Set((581.0f - cx) / PTM_RATIO, (cy - 1909.0f) / PTM_RATIO);
		vertices[2].Set((719.0f - cx) / PTM_RATIO, (cy - 1909.0f) / PTM_RATIO);

		int32 count = 3;		

		polygon.Set(vertices, count);

		fixtureDef.shape = &polygon;
	}
		break;

	case BlockType::CIRCLE:
		circle.m_radius = 70.f / (2 * PTM_RATIO);
		fixtureDef.shape = &circle;
		break;
	case BlockType::RECTANGLE:
		polygon.SetAsBox(220.0f / (2.f * PTM_RATIO), 140.0f / (2.f * PTM_RATIO));
		fixtureDef.shape = &polygon;
		break;
	case BlockType::THIN_RECTANGLE:
		polygon.SetAsBox(70.0f / (2.f * PTM_RATIO), 220.0f / (2.f * PTM_RATIO));
		fixtureDef.shape = &polygon;
		break;
	case BlockType::SQUARE:
		polygon.SetAsBox(140.0f / (2.f * PTM_RATIO), 140.0f / (2.f * PTM_RATIO));
		fixtureDef.shape = &polygon;
		break;
	default:
		assert(false);
	}//end switch(btype)

	switch (mtype)
	{
	case MaterialType::WOOD:
		fixtureDef.density = 0.2f;
		fixtureDef.restitution = 0.05;
		fixtureDef.friction = 0.8;
		maximumHP += 200;
		break;
	case MaterialType::METAL:
		fixtureDef.density = 0.25f;
		fixtureDef.restitution = 0.05;
		fixtureDef.friction = 0.1;
		maximumHP += 300;
		break;
	case MaterialType::ICE:
		fixtureDef.density = 0.2f;
		fixtureDef.restitution = 0.05;
		fixtureDef.friction = 0.1;
		maximumHP += 50;
		break;
	case MaterialType::ROCK:
		fixtureDef.density = 0.2f;
		fixtureDef.restitution = 0.05;
		fixtureDef.friction = 0.1;
		maximumHP += 250;
		break;
	default:
		assert(false);
	}//end switch(mtype)

	blockEntity->body->CreateFixture(&fixtureDef);

	int numBlockTypesToSkip = (int) btype;
	int numMaterials = (int) MaterialType::END;
	int numSpritesToSkip = numBlockTypesToSkip * numMaterials * 3; //3 sprites per material/shape

	//add sprites
	blockEntity->sprite = blockSprites[numSpritesToSkip + (int)mtype *3];
	blockEntity->spriteList.push_back(blockSprites[numSpritesToSkip + (int)mtype * 3 + 1]);
	blockEntity->spriteList.push_back(blockSprites[numSpritesToSkip + (int)mtype * 3 + 2]);

	blockEntity->maxHP = blockEntity->hp = maximumHP;

	return blockEntity;	
}

void LoadMap(std::string fileName, std::vector<Entity*>& brickList)
{
	//clear the current brickList
	for (auto B : brickList) delete B;
	brickList.clear();

	//open file
	std::ifstream myfile;
	myfile.open(fileName);

	if (myfile.is_open())
	{
		//read in # of bricks
		int brickNum = 0;
		myfile >> brickNum;

		//read in each brick
		for (; brickNum > 0; --brickNum)
		{
			//make a brick
			int bNum = 0;
			int mNum = 0;
			int angle = 0;
			int x = 0;
			int y = 0;

			myfile >> bNum;
			myfile >> mNum;
			myfile >> angle;

			myfile >> x;
			myfile >> y;
			brickList.push_back(MakeBlock((BlockType)bNum, (MaterialType)mNum, b2Vec2(x + 2000, y), angle, 50));
		}

		myfile.close();
	}
}