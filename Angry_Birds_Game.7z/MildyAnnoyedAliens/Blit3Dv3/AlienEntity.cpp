#include "AlienEntity.h"


extern b2World* world;
extern std::vector<Sprite*> alienSprites;

AlienEntity* MakeAlien(b2Vec2 pixelCoords, int maximumHP, Sprite* sprite)
{
	AlienEntity* alienEntity = new AlienEntity();

	b2BodyDef bodyDef;

	bodyDef.type = b2_dynamicBody; //make it a dynamic body i.e. one moved by physics
	bodyDef.position = Pixels2Physics(pixelCoords); //set its position in the world
	//bodyDef.angle = deg2rad(angleInDegrees);

	bodyDef.angularDamping = 1.8f;

	bodyDef.userData.pointer = reinterpret_cast<uintptr_t> (alienEntity);

	alienEntity->body = world->CreateBody(&bodyDef); //create the body and add it to the world

	b2FixtureDef fixtureDef;

	// Define a shape for our body.
	b2PolygonShape polygon;

	polygon.SetAsBox(70.0f / (2.f * PTM_RATIO), 70.0f / (2.f * PTM_RATIO));
	fixtureDef.shape = &polygon;

	fixtureDef.density = 0.2f;
	fixtureDef.restitution = 0.05;
	fixtureDef.friction = 0.1;
	maximumHP += 50;
	
	alienEntity->body->CreateFixture(&fixtureDef);

	alienEntity->sprite = sprite;

	alienEntity->maxHP = alienEntity->hp = maximumHP;

	return alienEntity;

}
